package com.example.Portal.constant;

public class UserImplConstant {

    public static final String EMAIL_ALREADY_EXIST = "Email already exist";
    public static final String USERNAME_ALREADY_EXIST = "Username already exist";
    public static final String NO_USER_FOUND_BY_USERNAME = "No user found by username ";
    public static final String RETURNING_FOUND_USER_BY_USERNAME = "returning found user by username:";
    public static final String DEFAULT_USER_PROFILE_PATH = "/user/image/profile/";
    public static final String NO_USER_FOUND_BY_EMAIL = "No user found for email: ";
}
